from distutils.log import debug
import pickle
import json
import numpy as np
from flask import Flask, request, redirect, url_for, flash, jsonify,render_template,render_template_string
# from PIL import Image

import api

# from io import BytesIO
# from keras.preprocessing import image
# from tensorflow.keras.models import Model
# from tensorflow import keras

# from tensorflow.keras.models import Model
# from tensorflow.keras.applications.inception_v3 import preprocess_input

app = Flask(__name__)


@app.route("/", methods=['GET','POST'])
def titanic_model():
    return render_template("class_monitor.html")

@app.route("/callApi", methods=['POST','GET'])
def callApi():
    # name = request.form["uname"]
    # male = request.form["male"]
    # female = request.form["female"]
    # Fare = request.form["Fare"]
    # Age = request.form["Age"]
    # Pclass = request.form["Pclass"]
    # Embarked = request.form["Embarked"]
    # sex = int(request.form["sex"])
    # print(request.form,type(request.form)) 

    #print(data,type(data))
    # sensor data
    sensor_data = api.getSensorData("img-sensor", 0, "emotion_app")#returns float
    # print(sensor_data)
    # image = int(float(sensor_data))%100+1
    # sensor_data = api.getSensorData("temperature-sensor", 0, "corona_app")#returns float
    # print(sensor_data)
    # sex = int(float(sensor_data))%2
    # sensor_data = api.getSensorData("temperature-sensor", 0, "corona_app")#returns float
    # print(sensor_data)
    # fare = int(float(sensor_data))%500+1
    # sensor_data = api.getSensorData("temperature-sensor", 0, "corona_app")#returns float
    # print(sensor_data)
    # pclass = int(float(sensor_data))%3+1
    # sensor_data = api.getSensorData("temperature-sensor", 0, "corona_app")#returns float
    # print(sensor_data)
    # embarked = int(float(sensor_data))%3+1


    data = {
            "image": sensor_data
            # "Fare": fare,
            # "Age": age,
            # "Pclass": pclass,
            # "Embarked": embarked
        }

    # print(data)
    response = api.predict(data, "emotion_model")
    print(type(response), flush=True)
    print(response, flush=True)
    emotion = response['emotion']
    # angry = emotion['angry']
    # disgust = emotion['disgust']
    # fear = emotion['fear']
    # happy = emotion['happy']
    # sad = emotion['sad']
    # surprise = emotion['surprise']
    # neutral = emotion['neutral']
    dominant_emotion = emotion['dominant_emotion']
    
    if dominant_emotion == 'angry' or dominant_emotion == 'disgust' or dominant_emotion == 'fear' or dominant_emotion == 'sad':
        res = 0
    else:
        res = 1
    
    
    # content = response.json['content']
    
    print(res)
    if res == 0:
        response = "Negative emotion"
    else :
        response = "Positive emotion"
    return render_template_string('''<!doctype html>
<html>
    <head>
        <link rel="stylesheet" href="css url"/>
    </head>
    <body>
        <h1>'''+response+'''</h1>
    </body>
</html>
''')
    print(response)






if __name__ == "__main__":
    app.run(port=5001,debug=True)
